-- phpMyAdmin SQL Dump
-- version 2.8.2.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 02. Oktober 2006 um 11:01
-- Server Version: 5.0.24
-- PHP-Version: 5.2.0RC4
-- 
-- Datenbank: `access`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `aces`
-- 

CREATE TABLE `aces` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `acl` tinyint(3) unsigned NOT NULL,
  `group` tinyint(3) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `rights` set('Read','Change','Add','Delete') NOT NULL,
  `from` int(10) unsigned NOT NULL default '0',
  `until` int(10) unsigned NOT NULL default '2147483646',
  `order` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `order` (`order`),
  KEY `ace_list` (`acl`,`from`,`until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=8 ;

-- 
-- Daten für Tabelle `aces`
-- 

INSERT INTO `aces` (`id`, `acl`, `group`, `position`, `rights`, `from`, `until`, `order`) VALUES (1, 1, 4, 5, 'Read,Change,Add,Delete', 0, 2147483646, 0),
(2, 2, 4, 5, 'Read,Change,Add,Delete', 0, 2147483646, 0),
(3, 2, 2, 3, 'Read,Change,Add,Delete', 0, 2147483646, 0),
(4, 2, 3, 4, 'Read,Add', 0, 2147483646, 0),
(5, 2, 2, 1, 'Read,Change', 0, 2147483646, 0),
(6, 1, 2, 3, 'Read', 4, 5, 6),
(7, 1, 2, 2, 'Read,Change', 0, 4, 5);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `acls`
-- 

CREATE TABLE `acls` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 MAX_ROWS=300 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=3 ;

-- 
-- Daten für Tabelle `acls`
-- 

INSERT INTO `acls` (`id`, `name`) VALUES (1, 'ACL für Administratives'),
(2, 'ACL für Finanzen');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `base`
-- 

CREATE TABLE `base` (
  `id` mediumint(8) unsigned NOT NULL auto_increment COMMENT 'Die User ID',
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL default '2',
  `identifier` varchar(32) default NULL,
  `token` varchar(32) default NULL,
  `timeout` int(10) unsigned default NULL COMMENT 'Wann soll der Login ablaufen',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login` (`status`,`username`,`password`),
  UNIQUE KEY `check_logged_in` (`status`,`identifier`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1 COMMENT='Basisdaten der User für den Login' AUTO_INCREMENT=2 ;

-- 
-- Daten für Tabelle `base`
-- 

INSERT INTO `base` (`id`, `username`, `password`, `status`, `identifier`, `token`, `timeout`) VALUES (1, 'ABCDEF', '40cc62e16f1c4a0f876880fed507d1a6', 1, '0d863df884b69f7b8e4c76a18bb937be', '192dd1e3196fdfdf891bc17d55094a33', 17100);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `extended`
-- 

CREATE TABLE `extended` (
  `user` mediumint(8) unsigned NOT NULL,
  `firstname` varchar(200) default NULL,
  `lastname` varchar(200) default NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(200) default NULL,
  `zip` varchar(10) default NULL,
  `town` varchar(200) default NULL,
  `country` smallint(4) unsigned NOT NULL default '0' COMMENT 'see foreign table',
  `phone` varchar(50) default NULL,
  PRIMARY KEY  (`user`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1;

-- 
-- Daten für Tabelle `extended`
-- 

INSERT INTO `extended` (`user`, `firstname`, `lastname`, `email`, `address`, `zip`, `town`, `country`, `phone`) VALUES (1, 'AAAAAA', 'Min', 'rtgedfuoiooit7zrr99@wt3uiuuiuzizor.com', 'Pinselweg 12', '', '', 0, '');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `groups`
-- 

CREATE TABLE `groups` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 MAX_ROWS=300 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=5 ;

-- 
-- Daten für Tabelle `groups`
-- 

INSERT INTO `groups` (`id`, `name`) VALUES (1, 'All'),
(2, 'Finance'),
(3, 'Support'),
(4, 'Admin');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `history_base`
-- 

CREATE TABLE `history_base` (
  `id` mediumint(8) unsigned NOT NULL COMMENT 'Die User ID',
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL default '2',
  `identifier` varchar(32) default NULL,
  `token` varchar(32) default NULL,
  `timeout` int(10) unsigned default NULL COMMENT 'Wann soll der Login ablaufen',
  `date` int(10) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  KEY `id` (`id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1 COMMENT='Basisdaten der User für den Login';

-- 
-- Daten für Tabelle `history_base`
-- 

INSERT INTO `history_base` (`id`, `username`, `password`, `status`, `identifier`, `token`, `timeout`, `date`, `ip`) VALUES (1, 'ABCDEF', '40cc62e16f1c4a0f876880fed507d1a6', 1, '0d863df884b69f7b8e4c76a18bb937be', '192dd1e3196fdfdf891bc17d55094a33', 17100, 1159778789, 2130706433),
(1, 'ABCDEF', '40cc62e16f1c4a0f876880fed507d1a6', 1, '0d863df884b69f7b8e4c76a18bb937be', '192dd1e3196fdfdf891bc17d55094a33', 17100, 1159778810, 2130706433);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `history_extended`
-- 

CREATE TABLE `history_extended` (
  `user` mediumint(8) unsigned NOT NULL,
  `firstname` varchar(200) default NULL,
  `lastname` varchar(200) default NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(200) default NULL,
  `zip` varchar(10) default NULL,
  `town` varchar(200) default NULL,
  `country` smallint(4) unsigned NOT NULL default '0' COMMENT 'see foreign table',
  `phone` varchar(50) default NULL,
  `date` int(10) unsigned NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  KEY `user` (`user`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1;

-- 
-- Daten für Tabelle `history_extended`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `logins`
-- 

CREATE TABLE `logins` (
  `user` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL default '0',
  `ip` int(10) unsigned NOT NULL default '1',
  KEY `user` (`user`),
  KEY `date` (`date`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1;

-- 
-- Daten für Tabelle `logins`
-- 

INSERT INTO `logins` (`user`, `date`, `ip`) VALUES (1, 1159530463, 2130706433),
(1, 1159530472, 2130706433),
(1, 1159530473, 2130706433),
(1, 1159530474, 2130706433),
(1, 1159530505, 2130706433),
(1, 1159530506, 2130706433);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `meta`
-- 

CREATE TABLE `meta` (
  `user` mediumint(8) unsigned NOT NULL,
  `last_login_date` int(11) unsigned NOT NULL,
  `last_login_ip` int(11) unsigned NOT NULL COMMENT 'use INET_ATON/NET_NTOA',
  `last_change_date` int(11) unsigned NOT NULL,
  `last_change_ip` int(11) unsigned NOT NULL COMMENT 'use INET_ATON/NET_NTOA',
  `registration_date` int(11) unsigned NOT NULL,
  `registration_ip` int(11) unsigned NOT NULL COMMENT 'use INET_ATON/NET_NTOA',
  `confirmation_token` varchar(32) default NULL,
  PRIMARY KEY  (`user`),
  UNIQUE KEY `confirmation_token` (`confirmation_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1 COMMENT='Metadaten des Users';

-- 
-- Daten für Tabelle `meta`
-- 

INSERT INTO `meta` (`user`, `last_login_date`, `last_login_ip`, `last_change_date`, `last_change_ip`, `registration_date`, `registration_ip`, `confirmation_token`) VALUES (1, 1159530506, 2130706433, 1159778810, 2130706433, 1158749012, 1, 'aace77bc9ef9d13ab9806a14e08ee34a');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `positions`
-- 

CREATE TABLE `positions` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 MAX_ROWS=300 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=6 ;

-- 
-- Daten für Tabelle `positions`
-- 

INSERT INTO `positions` (`id`, `name`) VALUES (1, 'All'),
(2, 'Moderator'),
(3, 'Manager'),
(4, 'Member'),
(5, 'Administrator');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `roles`
-- 

CREATE TABLE `roles` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `user` mediumint(8) unsigned NOT NULL,
  `group` tinyint(3) unsigned NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `from` int(10) unsigned NOT NULL default '0',
  `until` int(10) unsigned NOT NULL default '2147483646',
  `order` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `order` (`order`),
  KEY `role_list` (`user`,`from`,`until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=14 ;

-- 
-- Daten für Tabelle `roles`
-- 

INSERT INTO `roles` (`id`, `user`, `group`, `position`, `from`, `until`, `order`) VALUES (1, 1, 2, 1, 0, 2000000000, 0),
(3, 1, 1, 1, 0, 2147483646, 1),
(4, 1, 1, 1, 0, 2147483646, 1),
(5, 1, 1, 1, 0, 2147483646, 1),
(6, 1, 1, 1, 0, 2147483647, 1),
(7, 1, 1, 1, 0, 2147483647, 1),
(8, 1, 1, 1, 4, 2147483647, 1),
(9, 1, 1, 1, 4, 2147483647, 1),
(10, 1, 1, 1, 4, 1147483649, 1),
(11, 1, 1, 1, 0, 1147483649, 1),
(12, 1, 1, 2, 3, 4, 5),
(13, 1, 1, 2, 3, 4, 5);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `status`
-- 

CREATE TABLE `status` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 MAX_ROWS=300 PACK_KEYS=1 DELAY_KEY_WRITE=1 AUTO_INCREMENT=7 ;

-- 
-- Daten für Tabelle `status`
-- 

INSERT INTO `status` (`id`, `name`) VALUES (1, 'Active'),
(2, 'Inactive'),
(3, 'Locked Permanently'),
(4, 'Locked Temporary'),
(5, 'Confirm Registration'),
(6, 'Confirm Email');

-- 
-- Constraints der exportierten Tabellen
-- 

-- 
-- Constraints der Tabelle `aces`
-- 
ALTER TABLE `aces`
  ADD CONSTRAINT `aces_ibfk_1` FOREIGN KEY (`acl`) REFERENCES `acls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints der Tabelle `base`
-- 
ALTER TABLE `base`
  ADD CONSTRAINT `base_ibfk_1` FOREIGN KEY (`status`) REFERENCES `status` (`id`) ON UPDATE CASCADE;

-- 
-- Constraints der Tabelle `extended`
-- 
ALTER TABLE `extended`
  ADD CONSTRAINT `extended_ibfk_1` FOREIGN KEY (`user`) REFERENCES `base` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints der Tabelle `history_base`
-- 
ALTER TABLE `history_base`
  ADD CONSTRAINT `history_base_ibfk_1` FOREIGN KEY (`id`) REFERENCES `base` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints der Tabelle `history_extended`
-- 
ALTER TABLE `history_extended`
  ADD CONSTRAINT `history_extended_ibfk_1` FOREIGN KEY (`user`) REFERENCES `base` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints der Tabelle `meta`
-- 
ALTER TABLE `meta`
  ADD CONSTRAINT `meta_ibfk_1` FOREIGN KEY (`user`) REFERENCES `base` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
