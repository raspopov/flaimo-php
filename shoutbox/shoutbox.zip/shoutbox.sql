# phpMyAdmin MySQL-Dump
# version 2.3.0
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Erstellungszeit: 04. November 2002 um 15:00
# Server Version: 3.23.52
# PHP-Version: 4.2.3
# Datenbank: `shoutbox`
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_shoutbox`
#

CREATE TABLE tbl_shoutbox (
  id int(10) unsigned NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  mail tinytext,
  message text NOT NULL,
  date datetime NOT NULL default '0000-00-00 00:00:00',
  ip varchar(15) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Daten f�r Tabelle `tbl_shoutbox`
#

INSERT INTO tbl_shoutbox VALUES (1, 'Flaimo', 'flaimo@gmx.net', 'erge e zcv6z e6z erz6 6rez re', '2002-07-14 03:19:36', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (2, 'lguhljkhgl', 'flaimo@gmx.net', 'luzglgzlgz', '2002-07-14 18:50:46', NULL);
INSERT INTO tbl_shoutbox VALUES (3, 'uotzuio', 'ouzt', 'ouzt', '2002-07-14 19:14:22', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (4, 'ou7zt', 'ouzt', 'ouzt', '2002-07-14 19:14:29', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (5, 'ou7zt', 'ouzt', 'ouzt', '2002-07-14 19:15:06', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (6, 'ou7zt', 'ouzt', 'ouzt', '2002-07-14 19:15:28', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (7, '8opu', '�98u', '�98u', '2002-07-14 19:15:35', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (8, '8opu', '�98u', '�98u', '2002-07-14 19:16:09', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (9, 'Flaimo', 'flaimo@gmx.net', 'Ron Sommer h�lt seine Unternehmensstrategie nach wie vor f�r richtig. Der angeblich f�r die Nachfolge favorisierte Technik-Vorstand Gerd Tenzer wird derweil als �bergangskandidat gehandelt. mehr...', '2002-07-14 19:17:09', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (10, 'Flaimo', 'flaimo@gmx.net', 'Ron Sommer h�lt seine Unternehmensstrategie nach wie vor f�r richtig. Der angeblich f�r die Nachfolge favorisierte Technik-Vorstand Gerd Tenzer wird derweil als �bergangskandidat gehandelt. mehr...', '2002-07-14 19:17:53', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (11, 'ou7zt', 'ouzt', '�o8uzpiozupi', '2002-07-16 01:52:37', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (12, 'ou7zt', 'ouzt', '�o8uzpiozupi', '2002-07-16 01:59:26', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (13, 'Flaimo', 'flaimo@gmx.net', 'li7tz pi p9zp9 \r\ntzutuuru647i\r\nt7iu64i64j46j64j46j\r\n46uj46kj74kjzjzrj7zkj75j\r\nz7ik7k75\r\n748k75k75k7', '2002-07-16 02:01:37', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (14, 'ou7zt', 'ouzt', 'auf http://orf.at ist ein guter artikel', '2002-07-21 00:11:01', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (15, 'Felix Poppeikoff', 'felix.poppeikoff@aon.at', 'Ron Sommer h�lt seine Unternehmensstrategie nach wie vor f�r richtig. Der angeblich f�r die Nachfolge favorisierte Technik-Vorstand Gerd Tenzer wird derweil als �bergangskandidat gehandelt.', '2002-07-26 20:30:29', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (16, 'Felix Poppeikoff', 'felix.poppeikoff@aon.at', ',ztf khfkuztgf kuz', '2002-07-26 22:07:44', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (17, 'Felix Poppeikoff', 'felix.poppeikoff@aon.at', '  Nulls and zeros  Zitan 3 44  July 26th, 2002 01:36 PM\r\nby rod k   \r\n \r\n    Subdomains  mizzory 6 81  July 26th, 2002 01:25 PM\r\nby maytricks   \r\n \r\n    multipurpose page and switch  zico 1 16  July 26th, 2002 01:18 PM\r\nby Mirax   \r\n \r\n    Displaying a List of Members Logged in  benm2750 1 26  July 26th, 2002 01:17 PM\r\nby jpenn   \r\n \r\n    parse error defining a custom function  \r\n', '2002-07-27 12:25:22', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (18, 'Felix Poppeikoff', 'felix.poppeikoff@aon.at', 'pi7z', '2002-07-28 23:15:23', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (19, 'p876z0', '�967', 'p98zp', '2002-08-18 01:48:36', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (20, 'p876z0', '�967', 'piuzpiouz', '2002-08-25 22:55:12', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (21, 'p876z0', '�967', '�o9up�9oup', '2002-09-10 17:53:28', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (22, 'p876z0', '�967', 'noch ein test', '2002-09-10 18:26:30', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (23, 'qwertz', 'qwert', 'qwert', '2002-09-16 17:18:17', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (24, 'iuozouz', 'ouztioutzio', 'oiuzoiu', '2002-09-16 17:20:27', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (25, 'qwertz', 'qwert', 'uztiutziuztu', '2002-09-16 17:56:03', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (26, 'iuozouz', 'ouztioutzio', 'p98709870987', '2002-09-16 17:56:24', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (27, '098�9', '�08�08', '�089�089�', '2002-09-16 17:57:27', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (28, 'qwertz', 'qwert', '�7987098709', '2002-09-16 18:02:09', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (29, 'qwertz', 'qwert', 'das ist ein test', '2002-09-16 18:03:07', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (30, 'iuozouz', 'flaimo@gmx.net', 'test', '2002-09-16 18:04:37', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (31, 'qwertz', '', '�98�897�878�0', '2002-09-16 18:22:34', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (32, 'iuozouz', 'flaimo@gmx.net', '87687698769876', '2002-09-16 18:23:00', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (33, '098�9', '', '097606897698', '2002-09-16 18:24:58', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (34, 'qwertz', 'qwert', 'uiztiztrizt', '2002-09-16 20:53:25', '127.0.0.1');
INSERT INTO tbl_shoutbox VALUES (35, '098�9', '�089��09', '��089�98', '2002-09-16 20:53:54', '127.0.0.1');

