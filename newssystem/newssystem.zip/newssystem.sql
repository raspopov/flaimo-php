# phpMyAdmin MySQL-Dump
# version 2.3.0
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Erstellungszeit: 04. November 2002 um 14:59
# Server Version: 3.23.52
# PHP-Version: 4.2.3
# Datenbank: `newssystem`
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_author`
#

CREATE TABLE tbl_author (
  IDAuthor tinyint(3) unsigned NOT NULL auto_increment,
  AuthorNick text,
  AuthorRealName text,
  AuthorPassword text,
  AuthorEmail text,
  Abstract_de text,
  Abstract_en text,
  EditNews char(1) default 'y',
  EditCat char(1) default NULL,
  Picture tinytext,
  AllowedCats tinytext NOT NULL,
  PRIMARY KEY  (IDAuthor)
) TYPE=MyISAM;

#
# Daten f�r Tabelle `tbl_author`
#

INSERT INTO tbl_author VALUES (1, 'admin', 'Administrator', 'alyssa05te', 'admin@yourhost.com', NULL, NULL, 'y', 'y', NULL, '2,3,4,5,6,7,8,9,10');
INSERT INTO tbl_author VALUES (2, 'Flaimo', '', 'alyssa04pc', 'flaimo@flaimo.com', 'Suchmaschinen-Betreiber wollen Geld verdienen: Ganz oben auf den Hitlisten der Internet-Pfadfinder stehen deshalb nicht immer die besten, sondern immer �fter die zahlungskr�ftigsten Websites. Das mag f�r normale Internet-Surfer an Betrug grenzen, verst��t aber gegen kein Gesetz. Die US-amerikanische Federal Trade Commission (FTC) mahnt jetzt acht Suchmaschinen, darunter auch AltaVista, AOL Time Warner, LookSmart, Microsoft und Terra Lycos, bezahlte Werbelinks auch deutlich als solche zu kennzeichnen. Sollten die Suchmaschinenbetreiber nicht reagieren, droht die FTC jedoch nicht mit Sanktionen. \r\n\r\n \r\nSuchmaschinen-Betreiber mischen bezahlte Werbelinks unter die normalen Suchergebnise, und nur wenige merken es. Rund 60 Prozent der Internet-Nutzer surfen recht blau�ugig durchs Web und trauen den Anbietern solche Tricksereien gar nicht zu, haben Umfragen ergeben. Besonders LookSmart l�sst sich nahezu jeden Link bezahlen: Je weiter oben auf der Hitliste, desto teurer wird der Spa�.\r\n\r\nAuf die schmutzigen Geheimnisse der Suchmaschinen-Macher war die FTC durch eine Beschwerde der amerikanischen B�rgerrechtsbewegung Commercial Alert aufmerksam geworden, der auch der Verbraucherschutz-Aktivist Ralph Nader angeh�rt. Die Anbieter der Suchwerkzeuge "stellen Profitgier (commercialism) �ber journalistische Integrit�t", urteilt Gary Ruskin, gesch�ftsf�hrender Direktor von Commercial Alert. "Das ist nur das letzte Beispiel, wie Werbung in jeden Winkel unseres Lebens kriecht. Wir Amerikaner haben genug davon." (ku/c\'t) \r\n', 'Suchmaschinen-Betreiber wollen Geld verdienen: Ganz oben auf den Hitlisten der Internet-Pfadfinder stehen deshalb nicht immer die besten, sondern immer �fter die zahlungskr�ftigsten Websites. Das mag f�r normale Internet-Surfer an Betrug grenzen, verst��t aber gegen kein Gesetz. Die US-amerikanische Federal Trade Commission (FTC) mahnt jetzt acht Suchmaschinen, darunter auch AltaVista, AOL Time Warner, LookSmart, Microsoft und Terra Lycos, bezahlte Werbelinks auch deutlich als solche zu kennzeichnen. Sollten die Suchmaschinenbetreiber nicht reagieren, droht die FTC jedoch nicht mit Sanktionen. \r\n\r\n \r\nSuchmaschinen-Betreiber mischen bezahlte Werbelinks unter die normalen Suchergebnise, und nur wenige merken es. Rund 60 Prozent der Internet-Nutzer surfen recht blau�ugig durchs Web und trauen den Anbietern solche Tricksereien gar nicht zu, haben Umfragen ergeben. Besonders LookSmart l�sst sich nahezu jeden Link bezahlen: Je weiter oben auf der Hitliste, desto teurer wird der Spa�.\r\n\r\nAuf die schmutzigen Geheimnisse der Suchmaschinen-Macher war die FTC durch eine Beschwerde der amerikanischen B�rgerrechtsbewegung Commercial Alert aufmerksam geworden, der auch der Verbraucherschutz-Aktivist Ralph Nader angeh�rt. Die Anbieter der Suchwerkzeuge "stellen Profitgier (commercialism) �ber journalistische Integrit�t", urteilt Gary Ruskin, gesch�ftsf�hrender Direktor von Commercial Alert. "Das ist nur das letzte Beispiel, wie Werbung in jeden Winkel unseres Lebens kriecht. Wir Amerikaner haben genug davon." (ku/c\'t) \r\n', 'y', 'y', 'evilserge.jpg', '2,3,4,5,6,7,8,9,10');
INSERT INTO tbl_author VALUES (3, 'Patrick', 'Patrick Butterer', 'maxmobil', 'patrick@charmed-net.de', NULL, NULL, 'y', NULL, NULL, '2,3,4,5,6,7,8,9,10');
INSERT INTO tbl_author VALUES (4, 'Simone', 'Simone', 'maxmobil', 'Simone@charmed-net.de', NULL, NULL, 'y', 'y', NULL, '2,3,4,5,6,7,8,9,10');
INSERT INTO tbl_author VALUES (5, 'Seeker', 'Seeker', 'charmednew', 'seeker@charmed-net.de', NULL, NULL, 'y', NULL, NULL, '7,8,9,10');
INSERT INTO tbl_author VALUES (6, 'Herb', 'Marcus Herberger', 'amnews01', '', NULL, NULL, 'y', NULL, NULL, '7,8,9,10');
INSERT INTO tbl_author VALUES (7, 'Eiko', 'Heike', 'charmednew', 'eiko@charmed-net.de', NULL, NULL, 'y', NULL, NULL, '2,3,4,5,6,7,8,9,10');
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_category`
#

CREATE TABLE tbl_category (
  IDCategory tinyint(3) unsigned NOT NULL auto_increment,
  Language varchar(4) NOT NULL default 'de',
  CategoryName tinytext NOT NULL,
  CategoryPosition tinyint(3) unsigned NOT NULL default '9',
  CategoryPassword text,
  PRIMARY KEY  (IDCategory),
  KEY Language (Language)
) TYPE=MyISAM;

#
# Daten f�r Tabelle `tbl_category`
#

INSERT INTO tbl_category VALUES (2, 'de', 'Offtopic', 1, '');
INSERT INTO tbl_category VALUES (3, 'de', 'The Real World', 2, '');
INSERT INTO tbl_category VALUES (4, 'de', 'Station Check', 3, '');
INSERT INTO tbl_category VALUES (5, 'de', 'About The Page', 4, '');
INSERT INTO tbl_category VALUES (6, 'de', 'New Technology', 5, '');
INSERT INTO tbl_category VALUES (7, 'en', 'Multimedia', 6, '');
INSERT INTO tbl_category VALUES (8, 'en', 'Books & Papers', 7, '');
INSERT INTO tbl_category VALUES (9, 'en', 'Video & DVD', 8, '');
INSERT INTO tbl_category VALUES (10, 'en', 'Local', 9, '');
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_comment`
#

CREATE TABLE tbl_comment (
  IDComment int(11) unsigned NOT NULL auto_increment,
  NewsID int(11) unsigned NOT NULL default '0',
  Language varchar(4) NOT NULL default 'de',
  CommentText mediumtext,
  CommentAuthor tinytext,
  CommentEmail tinytext,
  CommentDate datetime default NULL,
  CommentIP tinytext,
  PRIMARY KEY  (IDComment),
  KEY NewsID (NewsID),
  KEY Language (Language)
) TYPE=MyISAM;

#
# Daten f�r Tabelle `tbl_comment`
#

INSERT INTO tbl_comment VALUES (1, 1, 'de', 'p7zop7zozouzg', 'Flaimo', 'http://flaimo.com', '2002-06-29 00:50:52', '127.0.0.1');
INSERT INTO tbl_comment VALUES (2, 22, 'de', 'Sage und schreibe nur 14 Artikel heute, davon ein Samstagsstandart,\r\nein tats�chlich einschlagender mit M�he noch zwei interessante und\r\nder Rest Flautenpeinlichkeiten! UND DAZU NOCH IMMER H�UFIGER\r\nWERBEBLOCKS IM TEXT!\r\nTilda', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-29 20:32:39', '127.0.0.1');
INSERT INTO tbl_comment VALUES (3, 25, 'de', 'khtzfjzhtrfj', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-30 23:26:51', '127.0.0.1');
INSERT INTO tbl_comment VALUES (4, 1, 'de', 'hgfdjhf vtfj f', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-30 23:27:02', '127.0.0.1');
INSERT INTO tbl_comment VALUES (5, 1, 'de', 'o7tiuztiut', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-30 23:43:04', '127.0.0.1');
INSERT INTO tbl_comment VALUES (6, 25, 'de', 'Firmenbosse in den USA sollen k�nftig mehr Verantwortung f�r die Finanzberichte ihrer Unternehmen �bernehmen. Dazu verpflichtet sie die US-B�rsenaufsicht SEC, die Richtigkeit der Berichte schriftlich zu best�tigen. Dadurch k�nnen die Firmen- und Finanz-Chefs f�r gesch�nte oder gef�lschte Bilanzen besser zur Verantwortung gezogen werden. Betroffen sind Unternehmen mit Jahreseinnahmen �ber 1,2 Milliarden US-Dollar. Die Anordnung gilt ab 14. August. ', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-30 23:45:50', '127.0.0.1');
INSERT INTO tbl_comment VALUES (7, 25, 'de', 'Buffy ist z.B. eine Serie.', 'Tilda Flames', 'mailto:sfxwin@gmx.de', '2002-06-30 23:58:45', '127.0.0.1');
INSERT INTO tbl_comment VALUES (8, 25, 'de', 'Mein Senf', 'Michael', 'flaimo@flaimo.com', '2002-07-01 01:48:05', '127.0.0.1');
INSERT INTO tbl_comment VALUES (9, 47, 'de', 'kuztkuzt', 'Michael', 'flaimo@flaimo.com', '2002-07-08 09:28:29', '127.0.0.1');
INSERT INTO tbl_comment VALUES (10, 34, 'en', 'http://flaimo.com ist die beste seite', 'Michael', 'flaimo@flaimo.com', '2002-07-21 00:05:39', '127.0.0.1');
INSERT INTO tbl_comment VALUES (11, 1, 'de', 'kztizt', 'Michael', 'flaimo@flaimo.com', '2002-07-27 14:08:29', '127.0.0.1');
INSERT INTO tbl_comment VALUES (12, 47, 'de', 'iuzoiu', 'Michael', 'http://flaimo.com', '2002-07-27 14:20:49', '127.0.0.1');
INSERT INTO tbl_comment VALUES (13, 48, 'de', 'Michi', 'Michi', 'http://flaimo.com', '2002-08-18 19:57:25', '127.0.0.1');
INSERT INTO tbl_comment VALUES (14, 47, 'de', 'zahlen', 'Michi', 'http://flaimo.com', '2002-08-18 19:58:18', '127.0.0.1');
INSERT INTO tbl_comment VALUES (15, 48, 'de', 'mal schaun ob kommentare gehen', 'Michi', 'http://flaimo.com', '2002-09-13 20:54:34', '127.0.0.1');
INSERT INTO tbl_comment VALUES (16, 25, 'de', '8768097', 'New Technology', 'http://flaimo.com', '2002-09-14 18:29:38', '127.0.0.1');
INSERT INTO tbl_comment VALUES (17, 25, 'de', 'test', 'New Technology', 'http://flaimo.com', '2002-09-23 03:58:43', '127.0.0.1');
INSERT INTO tbl_comment VALUES (18, 47, 'de', 'wieso', 'New Technology', 'http://flaimo.com', '2002-09-23 03:59:42', '127.0.0.1');
INSERT INTO tbl_comment VALUES (19, 3, 'de', 'ziuzoiuzoiuzoiu', 'Flaimo', 'http://flaimo.com', '2002-09-23 04:06:16', '127.0.0.1');
INSERT INTO tbl_comment VALUES (20, 48, 'de', 'vgbnfgnfg', 'Flaimo', 'http://flaimo.com', '2002-09-24 00:57:58', '127.0.0.1');
INSERT INTO tbl_comment VALUES (21, 25, 'de', 'jetz gehts aber', 'Flaimo', 'http://flaimo.com', '2002-09-24 01:15:58', '127.0.0.1');
INSERT INTO tbl_comment VALUES (22, 24, 'de', 'drztgrtz', 'Flaimo', 'http://flaimo.com', '2002-09-24 01:22:46', '127.0.0.1');
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_news`
#

CREATE TABLE tbl_news (
  IDNews int(11) unsigned NOT NULL auto_increment,
  Language varchar(4) NOT NULL default 'de',
  NewsHeadline text,
  NewsText mediumtext,
  NewsSource tinytext,
  NewsSourceLink tinytext,
  NewsDate datetime default NULL,
  NewsAuthor int(11) unsigned default NULL,
  NewsCategory int(11) unsigned NOT NULL default '0',
  NewsChangedBy int(11) unsigned default NULL,
  NewsChangedDate datetime default NULL,
  NewsRead int(11) unsigned NOT NULL default '0',
  NewsImage tinytext,
  NewsImageAlttext tinytext,
  NewsLinks text,
  expireDate datetime default NULL,
  releaseDate datetime default NULL,
  NoComments char(1) NOT NULL default '0',
  ShowFullText char(1) NOT NULL default '0',
  PRIMARY KEY  (IDNews),
  KEY NewsAuthor (NewsAuthor),
  KEY NewsCategory (NewsCategory),
  KEY Language (Language)
) TYPE=MyISAM;

#
# Daten f�r Tabelle `tbl_news`
#

INSERT INTO tbl_news VALUES (1, 'de', 'Erste Nachricht in Deutsch', 'Erste Nachricht in Deutsch', NULL, NULL, '2002-06-29 00:05:45', 2, 2, NULL, '2002-06-29 00:05:45', 49, NULL, '', NULL, '2002-06-29 00:05:45', '2002-06-29 00:05:45', '0', '0');
INSERT INTO tbl_news VALUES (2, 'en', 'English News', 'English News', NULL, NULL, '2002-06-29 00:06:25', 5, 9, NULL, '2002-06-29 00:06:25', 7, NULL, '', NULL, '2002-06-29 00:06:25', '2002-06-29 00:06:25', '0', '0');
INSERT INTO tbl_news VALUES (3, 'de', 'ouztouztou Buffy z.B.', 'ouztouztou Buffy z.B.', '', '', '2002-06-29 01:04:52', 2, 6, NULL, NULL, 14, '', '', '', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (22, 'de', 'Gekaufte Suchmaschinentreffer', 'Suchmaschinen-Betreiber wollen Geld verdienen: Ganz oben auf den Hitlisten der Internet-Pfadfinder stehen deshalb nicht immer die besten, sondern immer �fter die zahlungskr�ftigsten Websites. Das mag f�r normale Internet-Surfer an Betrug grenzen, verst��t aber gegen kein Gesetz. Die US-amerikanische Federal Trade Commission (FTC) mahnt jetzt acht Suchmaschinen, darunter auch AltaVista, AOL Time Warner, LookSmart, Microsoft und Terra Lycos, bezahlte Werbelinks auch deutlich als solche zu kennzeichnen. Sollten die Suchmaschinenbetreiber nicht reagieren, droht die FTC jedoch nicht mit Sanktionen. \r\n\r\n \r\nSuchmaschinen-Betreiber mischen bezahlte Werbelinks unter die normalen Suchergebnise, und nur wenige merken es. Rund 60 Prozent der Internet-Nutzer surfen recht blau�ugig durchs Web und trauen den Anbietern solche Tricksereien gar nicht zu, haben Umfragen ergeben. Besonders LookSmart l�sst sich nahezu jeden Link bezahlen: Je weiter oben auf der Hitliste, desto teurer wird der Spa�.\r\n\r\nAuf die schmutzigen Geheimnisse der Suchmaschinen-Macher war die FTC durch eine Beschwerde der amerikanischen B�rgerrechtsbewegung Commercial Alert aufmerksam geworden, der auch der Verbraucherschutz-Aktivist Ralph Nader angeh�rt. Die Anbieter der Suchwerkzeuge "stellen Profitgier (commercialism) �ber journalistische Integrit�t", urteilt Gary Ruskin, gesch�ftsf�hrender Direktor von Commercial Alert. "Das ist nur das letzte Beispiel, wie Werbung in jeden Winkel unseres Lebens kriecht. Wir Amerikaner haben genug davon." (ku/c\'t) \r\n', 'heise Verlag', 'http://www.heise.de/', '2002-06-29 20:31:22', 2, 3, NULL, NULL, 11, '', '', 'Commercial Alert,http://www.commercialalert.org/', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (23, 'de', '150 000 chinesische Internet-Caf�s vor dem Aus', 'Nach einem Brand in einem Internet-Caf� in Peking wollen die Beh�rden in China rund 150.000 ohne Lizenz betriebene Lokale f�r Internetsurfer schlie�en. Kritiker bef�rchten eine Einschr�nkung der Informationsm�glichkeiten der B�rger. Bis Ende August sollen die ohne Lizenz betriebenen Internet-Caf�s zugemacht und die Betreiber und Vermieter strafrechtlich verfolgt werden, berichtete die amtliche Nachrichtenagentur Xinhua am Samstag. \r\n\r\n \r\nMitte Juni waren bei dem Feuer in einem illegal gef�hrten Internet-Caf� in der Hauptstadt 24 Menschen ums Leben gekommen. Nur rund 46 000 von den gesch�tzten 200 000 Internet-Caf�s in China sind offiziell gemeldet. In Schanghai waren bereits vor wenigen Tagen 244 Internet-Bars geschlossen worden.\r\n\r\nNach Ansicht von Kritikern werden viele Internet-Caf�s illegal betrieben, weil die Regeln der kommunistischen Beh�rden f�r diese Szene so strikt sind. Die Regierung Chinas kontrolliert den Zugang zum Netz und blockiert politisch sensible oder obsz�ne Inhalte. Das Hongkonger Informationszentrum f�r Menschenrechte und Demokratie berichtete am Freitag, die Polizei habe bereits in den vergangenen zehn Jahren Tausende von Internet-Caf�s geschlossen, die keine Software zum Nachverfolgen der Wege durchs Netz installiert hatten. (dpa) (gr/c\'t) \r\n', 'heise Verlag', 'http://www.heise.de/', '2002-06-29 20:51:32', 2, 3, NULL, NULL, 24, '', '', 'Brand in einem Internet-Caf�,http://www.heise.de/newsticker/result.xhtml?url=/newsticker/data/jk-16.06.02-003', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (24, 'de', 'Lycos-Suchmaschine aufgebohrt', 'Am morgigen Sonntag will TerraLycos seine Suchmaschine in der neuen Version 6.0 enth�llen. \r\n\r\n \r\nWie das Online-Magazin pcworld.com mitteilt, werde die Suchmaschine dem Anwender dann Zugriff auf mehr als zwei Milliarden Volltextseiten gew�hren, wobei der Katalog alle neun Tage komplett aufgefrischt werde. Hinzu k�men neue Werkzeuge, die es dem Anwender leichter machen sollen, das zu finden, was er wirklich sucht. Au�erdem habe Lycos jetzt auch einige Millionen PDF-Dokumente im Zugriff.\r\n\r\nBesonders stolz sei TerraLycos auf die neu eingebaute Nachrichtensuche, die angeblich den Suchbestand von mehr als 3000 News Sites alle 60 Sekunden aufdatiere. Schon Ende 2001 hat TerraLycos einige Anstrengungen unternommen, sich im Wettbewerb der Suchmaschinen technisch auf aktuellen Stand zu bringen, wie der auf Suchmaschinen spezialisierte News-Dienst Searchenginewatch beobachtet hat. \r\n\r\nOffen bleibt allerdings zun�chst, ob beziehungsweise wann die Nutzer nationaler Lycos-Ableger in den Genuss der Neuerungen kommen. Weder auf www.lycos.com noch auf www.lycos.de finden sich bisher Hinweise �ber Startzeitpunkt und Umfang der Neuerungen. Bleibt also nur der Selbstversuch kontra Google & Co. am Sonntag. (gr/c\'t) \r\n', 'heise Verlag', 'http://www.heise.de/', '2002-06-29 20:53:03', 2, 3, NULL, NULL, 57, '', '', '', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (25, 'de', 'Ron Sommer verzichtet auf Aktien-Optionen', 'Der Vorstandschef der Deutschen Telekom, Ron Sommer, bedauert, dass er und seine Vorstandskollegen erst so sp�t auf die umstrittenen Aktienoptionen verzichtet haben. "Die Wahrheit ist, dass wir auf einen wesentlichen Teil unseres Einkommens verzichten. Wir machen uns nat�rlich den Vorwurf, dass wir das schneller und fr�her h�tten entscheiden k�nnen", sagte Sommer im Gespr�ch mit dem Berliner Tagesspiegel (Sonntagsausgabe). \r\n\r\n \r\nDer Vorstand hatte auf seine Aktienoptionen f�r das Jahr 2002 verzichtet, nachdem es auf der Hauptversammlung der Telekom massive Kritik an der Erh�hung der Vorstandsgeh�lter im vergangenen Jahr gegeben hatte.\r\n\r\n"Wir wollen auch bei der Frage der Einzelpublizit�t von Vorstandsgeh�ltern nicht die ersten sein, die das ver�ffentlichen. Wenn es einen Konsens unter den Dax-Unternehmen dar�ber g�be, w�rden wir aber sofort mitmachen. Ich glaube, dass wir in Deutschland dahin kommen werden und ich pers�nlich habe auch kein Problem damit", sagte Sommer.\r\n\r\nDer Telekom-Chef unterstrich, das wichtigste Thema im Unternehmen sei nun der Abbau der Schulden. Skeptisch �u�erte er sich allerdings zu der Frage, ob der B�rsengang der Mobilfunktochtergesellschaft T- Mobile noch in diesem Jahr stattfinden kann. "Die Wahrscheinlichkeit ist sehr gering. Im Augenblick sieht es nicht so aus, als w�rde sich der Markt erholen. Wir stellen uns mit unserem Gesch�ft darauf ein, dass der B�rsengang in diesem Jahr nicht kommt."(dpa) (ku/c\'t) \r\n', '', '', '2002-06-29 20:54:55', 2, 3, NULL, NULL, 151, '', '', '', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (26, 'en', 'Apple-Manager im Zwielicht', 'Zweimal in den letzten beiden Jahren verkauften Apple-Manager Aktien im Werte von mehreren Millionen US-Dollar, kurz bevor die Papiere mit dem Apfel-Logo an den B�rsen der Welt ins Straucheln gerieten. "Das sieht nach gutem Timing aus", meint Lon Gerber, Direktor der Abteilung Insider Research bei Thomson Financial. Jetzt sehen sich auch die Apple-Granden dem schmutzigen Verdacht des Insider-Handels ausgesetzt. \r\n\r\n \r\nDie gr��ten Verk�ufe t�tigten Fred Anderson, Chief Financial Officer bei Apple, und f�nf seiner Kollegen zwischen dem 22. April und 31. Mai dieses Jahres. 1,9 Millionen Aktien im Gesamtwert von mehr als 49 Millionen US-Dollar suchten sich auf dem B�rsenparkett neue Besitzer. Der Preis pro Aktie lag bei rund 24 Dollar.\r\n\r\nEinige Tage sp�ter, am 18. Juni, musste Apple seine Gewinnprognosen f�r das zweiten Quartal des laufenden Gesch�ftsjahres nach unten korrigieren. Prompt rutschten die Papiere des iMac-Erfinders auf 17 Dollar ab.\r\n\r\nDas gleiche Ding zogen die Apple-Manager vor zwei Jahren schon einmal durch. Damals brachten drei der auch in diesem Jahr an der B�rse t�tigen Apple-Chefs, die Senior Vice Presidents Avie Tevanian, Sina Tamaddon und Strategieberaterin Nancy Heinen, mehr als 370.000 Aktien im Gesamtwert von mehr als 21 Millionen US-Dollar unter die Leute. Auch Senior Vice President Jon Rubinstein, verantwortlich f�r den Hardware-Bereich, war mit von der Partie. Einen Monat sp�ter geriet das Apple-Papier wegen einer Gewinnwarnung ins Trudeln.\r\n\r\nUm den gesch�ftssch�digenden Verdacht auf Insider-Handel schon im Keim zu ersticken, legen Unternehmen ihren Managern, die Aktien verkaufen wollen, strenge Bedingungen auf. Im Fachjargon spricht man von "Trading Windows". Die C-Klasse der F�hrungsriege darf seine Papierer nur zu bestimmten Zeiten an der B�rse zum Verkauf anbieten, und nicht dann, wann es den Chefs aufgrund ihres Insider-Wissens gerade besonders g�nstig erscheint. Trotzdem weichen die internen Regeln, was den Aktienhandel betrifft, von Unternehmen zu Unternehmen stark voneinander ab. Bis jetzt war Apple nicht bereit, seine Gesch�ftspolitik in punkto B�rse (policy on trading windows) offenzulegen. (ku/c\'t) \r\n', '', '', '2002-06-29 21:00:41', 5, 10, NULL, NULL, 5, '3koepfaffe.gif', '', '', NULL, NULL, '1', '0');
INSERT INTO tbl_news VALUES (27, 'de', 'IDT will bis zu 4 Milliarden US-Dollar f�r WorldCom-Sparte bieten', 'Das US-amerikanische Telecomunternehmen IDT will 3 bis 4 Milliarden US-Dollar f�r die MFS Communications-Sparte des Telecomkonzerns WorldCom zahlen. Das w�ren etwa zehn Milliarden US-Dollar weniger als das in einen Buchf�hrungsskandal verwickelte Unternehmen WorldCom vor sechs Jahren f�r MFS Communications hingebl�ttert hatte, berichtete die New York Times am Samstag. \r\n  \r\nLaut dem Bericht hat IDT-Chef Howard S. Jonas sein Interesse an MFS bekundet. Er hatte in letzter Zeit zahlreiche Verm�genswerte bankrotter US-amerikanischer Telefongesellschaften zu Billigpreise erworben. IDT mit Sitz in Newark bietet Telefon-, Internet-Telefon- und Datendienste an.\r\n\r\nWorldCom hatte am Freitag mit der Entlassung von 17.000 Mitarbeitern begonnen. Das sind mehr als 20 Prozent der Gesamtbelegschaft.\r\n\r\nEin New Yorker Richter will einen Beobachter f�r WorldCom einsetzen. Er solle "ungerechte Bereicherung" auf Grund der Buchf�hrungsmanipulationen des Unternehmens verhindern. Der Richter Jed S. Rakoff hat nach Angaben der Zeitung WorldCom untersagt, jeweils mehr als 100.000 Dollar an derzeitige oder fr�here Manager, Verwaltungsratsmitglieder und Mitarbeiter zu zahlen, ehe der Beobachter seine Arbeit aufgenommen hat.\r\n\r\nWorldCom verhandelt mit seinen Banken �ber ein neues Kreditabkommen von 5 Milliarden US-Dollar. Die Banken haben einen Gl�ubigerausschuss gebildet, der von der Citigroup und der Deutschen Bank gef�hrt wird. WorldCom schuldet den Banken 2,65 Milliarden US-Dollar und hat Gesamtschulden von mehr als 30 Milliarden US-Dollar. Die WorldCom-Banken haben nach Angaben der New York Times Investoren und Konkurrenten kontaktiert, um ihr Interesse an dem Kauf von gr��eren Bereichen der angeschlagenen Telekom-Gesellschaft herauszufinden.\r\n\r\nDie WorldCom-Spitzenmanager versuchen ihrerseits, einen Konkurs zu vermeiden. WorldCom hatte versucht, durch offensichtliche Buchf�lschungen in H�he von 3,85 Milliarden US-Dollar tats�chliche Verluste f�r die vergangenen f�nf Quartale in Gewinne zu verwandeln. (dpa) / (anw/c\'t) \r\n\r\n', '', '', '2002-06-29 21:04:06', 2, 2, NULL, NULL, 23, 'evilserge.jpg', 'Mein Avatar Icon', '', NULL, NULL, '1', '0');
INSERT INTO tbl_news VALUES (28, 'de', 'Z�richer Flughafen will Gesichtserkennung einsetzen', 'Der Z�richer Flughafen will ein biometrisches Gesichtserkennungssystem einsetzen. Wie der "Spiegel" meldet, hat die Bochumer Firma C-Vis bereits die notwendige �berwachungstechnik geliefert. Ziel sei es, die Abschiebung von illegalen Asylbewerbern zu erleichtern, sagte C-Vis-Chef Thomas Zielke. Das System vergleiche die Gesichtsdaten einer illegal eingereisten Person mit Videoaufzeichnungen, um festzustellen, mit welcher Fluggesellschaft sie angekommen ist. Die Fluggesellschaft m�sse dann f�r den R�ckflug aufkommen. \r\n\r\n \r\nDas Gesichtserkennungssystem wird laut Zielke erstmals offiziell an einem Flughafen eingesetzt. "Im Geheimen" sei es jedoch schon l�nger auf Gro�flugh�fen in Gro�britannien und den Niederlanden getestet worden.\r\n\r\nDer Datenschutz-Beauftragte des Kantons Z�rich, Bruno Baeriswyl, sieht f�r den geplanten Einsatz des Systems keine rechtliche Grundlage. Seine Einw�nde seien aber nicht ber�cksichtigt worden, sagte er gegen�ber der "SonntagsZeitung". (ad/c\'t) \r\n', 'heise Verlag', 'http://www.heise.de/', '2002-07-01 00:47:01', 2, 5, NULL, NULL, 46, 'Hemp.gif', 'Hanf', 'Bruno Baeriswyl,http://www.datenschutz.ch/', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (31, 'en', '1&1 startet Anti-Spam-Initiative (Update)', 'Mit neuen Mail-Servern und Filtern will die 1&1-Internet AG (Puretec) unerw�nschten Werbe-E-Mails zu Leibe r�cken. Schon h�ufiger hatten sich Kunden �ber zu viele Spam-Mails in ihren Postf�chern beschwert. Damit soll jetzt Schluss sein. \r\n\r\n \r\nAls wirksame Ma�nahme gegen nervenden Werbem�ll gilt unter Experten das Transfer-Protokoll SMTP-auth. Im Gegensatz zum normalen SMTP m�ssen sich E-Mail-Versender unter SMTP-auth durch ein Passwort authentifizieren. Auf diese Weise wird es Spammern unm�glich gemacht, sich nach der Tat in den Schatten der Anonymit�t zu fl�chten. \r\n\r\nDer SMTP-auth-Server ist bei 1&1 der einzige Server, mit dem Kunden Massen-E-Mails versenden k�nnen. Auf dem alten SMTP-Server hat der Webhoster trickreich einen sogenannten Spam-Blocker installiert, der die Anzahl der versendeten Mails pro Benutzer und Stunde begrenzt. Mit der genauen Obergrenze f�r den E-Mail-Versand experimentiert 1&1 noch. Begonnen habe man mit 5000, sei aber dabei, das Limit langsam abzusenken, verriet Pressesprecherin Nicole Braun gegen�ber heise online. Denn seri�se Newsletter, die nicht schikanieren, sondern informieren, sollen f�r eine �bergangszeit noch �ber SMTP verschickt werden k�nnen. (ku/c\'t) \r\n', '', '', '2002-07-02 01:28:02', 2, 8, NULL, NULL, 6, '', '', '', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (32, 'en', 'Compuware erf�llt nicht die Erwartungen', 'Das US-amerikanische Softwareunternehmen Compuware erwartet f�r das am 30. Juni abgelaufene Quartal einen Umsatz zwischen 329 Millionen und 341 Millionen US-Dollar. Der Gewinn pro Aktie werde 5 oder 6 US-Cent betragen, hei�t es in einer Mitteilung des Unternehmens. Der Umsatz wird somit geringer ausfallen als Analysten an der Wall Street erwartet haben. Im Vergleichszeitraum des Vorjahres konnte Compuware 446 Millionen US-Dollar umsetzen. \r\n\r\n \r\nCompuware-Pr�sident Joe Nathan begr�ndet die Zahlen mit einer jahreszeitlich bedingten Schwankung. Dennoch arbeite sein Unternehmen immer noch profitabel. Genauere Erkl�rungen will er bei der offiziellen Vorstellung der Quartalsbilanz am 16. Juli abgeben. Im April hatte Compuware Stellenabbau und Standortschlie�ungen an seinem Stammsitz in Nordamerika und in Europa angek�ndigt. Laut US-amerikanischen Medien mussten rund 1000 Mitarbeiter gehen. (anw/c\'t) \r\n', 'heise Verlag', 'http://www.heise.de', '2002-07-03 19:11:03', 2, 10, NULL, NULL, 2, '', '', '', NULL, NULL, '1', '1');
INSERT INTO tbl_news VALUES (33, 'en', 'Schnurlos-Zubeh�r f�r Handy und PC', 'Mit der Wireless PC Card sowie dem Bluetooth Headset hat der Elektronikkonzern Motorola zwei Bluetooth-Ger�te auf den Markt gebracht. Die PC-Card soll drahtloser Kurzstreckenkommunikation mit entsprechenden Handys, PDAs oder Notebooks dienen. Das Ger�t ist f�r Rechner mit einem PC-Card-Steckplatz sowie den Betriebssystemen Windows 98, ME, 2000 sowie XP geeignet. \r\n\r\n \r\nZum Lieferumfang geh�rt die Kommunikations-Suite Phonetools, mit der sich zum Beispiel Adressen, Telefonnummern und Terminkalenderdaten zwischen PC und Handy �bertragen lassen. Zudem lassen sich mit der Bluetooth-Karte auch die in Bluetooth-Handys eingebauten GPRS- oder HSCSD-Modems zum mobilen Surfen nutzen oder Faxdokumente �bertragen. Die maximale Reichweite betr�gt laut Hersteller 10 Meter. Die Wireless PC Card ist laut Motorola seit Ende Juni im Fachhandel f�r 239 Euro erh�ltlich.\r\n\r\nDas Motorola Headset ist eine tragbare drahtlose Freisprecheinrichtung, die man zum Beispiel mit Motorolas Handy A830 koppeln k�nnen soll -- das Handy kommt aber voraussichtlich erst im Herbst auf den Markt. Mit Handy und Headset ausgestattet, d�rfen beispielsweise Autofahrer w�hrend der Fahrt telefonieren, denn beide H�nde k�nnen am Steuer bleiben, w�hrend das Handy etwa aus der Jackentasche heraus sowohl die GSM-Verbindung zum Mobilnetz als auch zum Headset aufrecht erh�lt. Die Entfernung zwischen Handy und Headset kann bis zu 10 Meter betragen.\r\n\r\nKlingelt das Bluetooth-f�hige Handy, reicht ein Knopfdruck am Headset, um das Gespr�ch anzunehmen. Eine direkte Sichtverbindung zwischen Headset und Handy ist -- wie bei allen Bluetooth-Ger�ten -- nicht notwendig. Ein Lithium-Polymer-Akku mit 150 mAh Kapazit�t liefert dem Headset laut Motorola ausreichend Strom f�r maximal drei Stunden lange Dauergespr�che; im Bereitschaftsmodus reicht eine Akkuladung f�r eine Woche. Im Handel ist das zusammenklappbare Ger�t mit einer G�rteltasche nebst Trageriemen f�r rund 239 Euro zu haben. Von Nokia, Ericsson und Philips gibt es bereits Bluetooth-Handys, die sich auch f�r die Kopplung mit Headsets eignen. Ob sie mit dem Motorola-Produkt "zusammenspielen" m�ssen aber erst noch entsprechende Tests zeigen.\r\n\r\nMotorolas noch kleine Bluetooth-Familie soll im Herbst um eine Freisprecheinrichtung f�rs Auto -- ein Car Kit -- erweitert werden. Gekoppelt mit einem entsprechenden Bluetooth-Handy soll der Autofahrer �ber das Car Kit Anrufe empfangen und beenden, die Lautst�rke regulieren sowie �ber Sprachwahl selbst anrufen k�nnen. Das Bluetooth Car Kit wird irgendwo im Auto in Bluetooth-Reichweite zum Handy platziert, etwa "an der Sonnenblende oder am Armaturenbrett", meldet Motorola. Es soll zum Preis von 289 in den Handel kommen. (dz/c\'t) \r\n', '', '', '2002-07-03 23:25:16', 2, 8, NULL, NULL, 8, '', '', '', NULL, NULL, '', '0');
INSERT INTO tbl_news VALUES (34, 'en', 'France Telecom hat noch keine L�sung f�r MobilCom', 'France Telecom hat noch keine L�sung f�r den Erwerb der Anteile von MobilCom-Gr�nder Gerhard Schmid am B�delsdorfer Mobilfunkanbieter gefunden. Die Verhandlungen verliefen sehr schwierig, berichtete die Wirtschaftszeitung La Tribune unter Berufung auf das Umfeld des Unternehmens. Der franz�sische Telekommunikationskonzern, der mit 28,5 Prozent an MobilCom beteiligt ist, steht nach dem Abgang von Schmid als Vorstandschef vor der diffizilen Aufgaben, sich �ber den Preis f�r das Paket des Firmengr�nders und seiner Frau von knapp 50 Prozent zu einigen. \r\n\r\n \r\nDas MobilCom-Problem stand am Mittwoch im Mittelpunkt einer Verwaltungsratssitzung in Paris, auf der die neue Regierung �ber den aktuellen Stand informiert wurde. Entscheidungen wurden nicht getroffen, hie� es. Der franz�sische Staat ist mit rund 55 Prozent an France Telecom beteiligt. France Telecom hat zwar mit den Bankengl�ubigern des deutschen Unternehmens eine grunds�tzliche Einigung f�r die Umschuldung von 4,7 Milliarden Euro gefunden, zur Stunde aber noch keine L�sung mit Nokia und Ericsson �ber die Lieferantenkredite in H�he von 1,1 Milliarden Euro erzielt. France Telecom hat selbst mit einem Schuldenberg von rund 65 Milliarden Euro zu k�mpfen und muss wegen schlechterer Einstufung der Kreditw�rdigkeit durch f�hrende US-Ratingagenturen mit hohen zus�tzlichen Belastungen rechnen.\r\n', '', '', '2002-07-03 23:42:05', 2, 7, NULL, NULL, 16, 'chickeneating.gif', 'Chicken', '', NULL, NULL, '0', '1');
INSERT INTO tbl_news VALUES (47, 'de', 'mjhgkujzghl', 'kjuztkjztluk7t', '', '', '2002-07-08 09:28:22', 2, 5, NULL, NULL, 36, '', '', '', NULL, NULL, '0', '0');
INSERT INTO tbl_news VALUES (48, 'de', 'mjhgkujzghl', 'kjuztkjztluk7t', '', '', '2002-07-08 09:32:08', 2, 5, NULL, NULL, 23, '', '', '', NULL, NULL, '0', '0');
# --------------------------------------------------------

#
# Tabellenstruktur f�r Tabelle `tbl_useronline`
#

CREATE TABLE tbl_useronline (
  ip char(15) NOT NULL default '',
  expire int(10) unsigned NOT NULL default '0',
  KEY ip (ip)
) TYPE=HEAP;

#
# Daten f�r Tabelle `tbl_useronline`
#


